function refreshRem() {
    // 设计稿的尺寸
    var desW = 640,
    // 动态获取当前屏幕的宽度
        winW = document.documentElement.clientWidth,
        ratio = winW / desW;
    document.documentElement.style.fontSize = ratio * 100 + 'px';
}
refreshRem();
window.addEventListener('resize', refreshRem);
